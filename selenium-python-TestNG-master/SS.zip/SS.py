import os,Index,sys
try:
    arg=sys.argv[1]
except:
    arg=None
IndexArg="-i"

if arg==IndexArg:
    print("""+----------------------------------------+
|                                        |
|   Welcome to :                         |
|                                        |
|   SUPER-SEARCHER                       |
|           -By TJ Production (c) 2018   |
+----------------------------------------+

INDEXING...

This window will close automatically after a successfull Indexing process, please
do not close this window.""")
    Index.Index()
    sys.exit()

doc="""
Welcome to 
    SUPER-SERCHER
        -By TJ Productions 2018
        (Tushar Jain Software Solutions)
                
1) Indexing- This means storing the name and location of your files present on your system in a file.
             Choosing this option will create/update your file Index, which then will be used to give
             you instant and up-to-date search results. To get upto date results, do indexing manually
             every alternate day, or let this app start at system startup. Press 4 in the Menu to add this
             app in startup.
             

2) Searching- A powerful and fast tool to search files in your system. It has a smart searching algorithm.
              Not only it displays results instaltly, but smartly also.
              Lets say you want to search a file, and its name big (eg. Common Dance Results India.txt), say
              you want to search this file, but you don't know its whole name, so you can just type
              'dance results common .txt' and it will show you your file. How cool!

3) Adding at startup- Tired of doing Indexing yourself again and again? Well then make it automatic. All this
                      app needs is your consent to run in the startup. So whenever the system will start, this
                      app will automatically index 


"""



try:
    f=open("ReadMe.txt")
    f.close()
except:
    f=open("ReadMe.txt","w")
    f.write(doc)
    f.close()


msg="""+----------------------------------------+
|                                        |
|   Welcome to :                         |
|                                        |
|   SUPER-SEARCHER                       |
|           -By TJ Production (c) 2018   |
+----------------------------------------+            

Options-

1) Indexing
          
2) Search

3) Open Help Documentation

4) Add to startup

5) Exit


"""



run=True
while run:
    os.system("cls")
    print (msg)
    err_str="Enter the option number"
    run2=True
    while run2:
        try:
            opt=input(err_str+" from 1, 2, 3, 4 or 5: ")
            opt=int(opt)
            run2=False
        except:
            os.system("cls")
            print (msg)
            err_str="Please enter option only"

    if opt==5:
        run=False

    if opt==1:
        os.system("cls")
        print("\n\nINDEXING\n\nPlease wait...")
        Index.Index()
        print ("\n\nPlease do this process of Indexing every alternate days\nor, as a consequence of which, you will get outdated search results")
        input("\n\nEnter to continue...")
        continue

    if opt==2:
        os.system("cls")
        print("\nSTARTING SEARCH ENGINE...\n\n")
        word_list=Index.get_word_list()
        Index.Search(word_list)
        while True:
            a=input("\n\nEnter 1 to continue...")
            if a=="1":
                break
            else:continue

    if opt==3:
        f=open("ReadMe.txt","w")
        f.write(doc)
        f.close()
        os.system("cls")
        print(doc)
        input("\n\nEnter to continue...")

    if opt==4:
        print ("Adding to startup...")
        loc=__file__+" -i"
        Index.addStartup(loc)
        input("\nDone\n\nEnter to continue...")
            
            
            
            
            
