import os,sys
from winreg import *

try:os.mkdir("Index")
except:pass


def make_drives():
    l=[]
    for i in range(65,92):
        l+=[chr(i)]

    return l

All_Drives=make_drives()

       
def Index(Drives=All_Drives):
    
    for Drive in Drives:
        n=0
        if os.path.isdir(Drive+":\\"):pass
        else:continue
        f=open("Index\\Drive "+Drive+".txt","w",encoding="utf-8")
        temp=[]
        for root, dirs, files in os.walk(Drive+':\\'):
            for file in files:
                name= root+'\\'+file+'\n'
                n+=1
                temp+=[name]
                if len(temp)>1024:
                    f.writelines(temp)
                    temp=[]
        f.writelines(temp)
        temp=[]

        plural="s"
        if n==1:
            plural=""        
        print (Drive+" Drive: "+str(n)+" file"+plural)
                
                

def Search(word_list, Drives=All_Drives):
    
    total=0
    for Drive in Drives:
        if os.path.isdir(Drive+":\\"):pass
        else:continue
        f=open("Index\\Drive "+Drive+".txt","r",encoding="utf-8")

        for line in f.readlines():
            LINE=line.upper()
            a=True
            for word in word_list:
                if word.upper() not in LINE:
                    a=False
                    break
                else:pass
            if a:
                print(line)
                total+=1
    plural="s"
    if total==1:
        plural=""
    print (total," result"+plural+" found")




def get_word_list():
    word=input("Enter filename to search: ")
    L=word.split()
    return L


def addStartup(filepath):
    new_file_path=filepath
    keyVal= r'Software\Microsoft\Windows\CurrentVersion\Run'

    key2change= OpenKey(HKEY_CURRENT_USER,
    keyVal,0,KEY_ALL_ACCESS)

    SetValueEx(key2change, "SUPER SEARCHER",0,REG_SZ, new_file_path)


addStartup("Startup.bat")
